# ROYALMATH — Mathematics Lab

Website matematik responsif bertema royal navy & gold. Versi awal ialah static website tanpa backend.

## Fungsi
- Kalkulator matematik dengan parser ungkapan terhad (tanpa `eval()`).
- Penyelesai persamaan linear `ax + b = c`.
- Penyelesai persamaan kuadratik `ax² + bx + c = 0`, termasuk punca kompleks.
- Graph Studio untuk fungsi matematik lazim, julat paksi yang boleh diubah, hover koordinat dan zoom roda tetikus.
- Formula Vault, reka bentuk responsif, Bahasa Melayu.

## Jalankan secara lokal
Buka `index.html` dalam pelayar moden. Sambungan internet tidak diperlukan.

## Terbitkan menggunakan GitHub Pages
1. Log masuk ke https://github.com/new
2. Repository name: `royalmath`
3. Pilih Public (atau Private jika pilihan Pages pelan/akaun anda menyokongnya).
4. Pilih **Add a README file** jika mahu, kemudian tekan **Create repository**.
5. Dalam repositori, pilih **Add file → Upload files** dan muat naik `index.html` serta `README.md` daripada folder ini.
6. Tekan **Commit changes**.
7. Pergi ke **Settings → Pages**. Pada Build and deployment, pilih **Deploy from a branch**; pilih `main` dan folder `/(root)`, kemudian **Save**.
8. Tunggu GitHub Pages selesai menerbitkan laman. Pautan lazimnya `https://USERNAME.github.io/royalmath/`.

## Had versi awal
Ini ialah asas berfungsi, bukan penyelesai simbolik universal. Ia belum menyokong semua jenis matematik, semua graf, sistem persamaan umum, derivatif/integral simbolik atau semakan automatik setiap soalan. Fungsi trigonometrik dalam kalkulator menggunakan darjah belum ditetapkan; kalkulator menggunakan radian seperti JavaScript. Graph Studio menggunakan radian. Semak jawapan penting secara berasingan.
